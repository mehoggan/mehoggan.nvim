---@meta
ndk = {}
ndk.set_var = {}
return ndk
