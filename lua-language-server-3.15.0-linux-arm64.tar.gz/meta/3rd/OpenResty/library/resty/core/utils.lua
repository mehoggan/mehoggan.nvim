---@meta
local resty_core_utils = {}

---@param str string
---@param find string
---@param replace string
---@return string
function resty_core_utils.str_replace_char(str, find, replace) end
resty_core_utils.version = require("resty.core.base").version
return resty_core_utils
